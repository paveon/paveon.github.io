---
title: Video of CurryOn Rome talk. Move Fast to Fix More Things
author: Peter O'Hearn
---

This is the video for Peter's talk at the
[Curry0n Conference](http://www.curry-on.org/2016/) in Rome in July. CurryOn is
a conference series where academia and industry get together to exchange ideas
about Programming Languages technology.

<iframe width="560" height="315" src="https://www.youtube.com/embed/xc72SYVU2QY?start=110" frameborder="0" allowfullscreen></iframe>
