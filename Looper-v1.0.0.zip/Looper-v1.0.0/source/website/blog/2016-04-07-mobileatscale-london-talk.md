---
title: Talk at Mobile@Scale London
author: Dulma Churchill
authorURL:
authorFBID:
---

<iframe width="560" height="315" src="https://www.facebook.com/plugins/video.php?width=560&height=315&href=https%3A%2F%2Fwww.facebook.com%2Fatscaleevents%2Fvideos%2F1708059786133785%2F&show_text=0"></iframe>
