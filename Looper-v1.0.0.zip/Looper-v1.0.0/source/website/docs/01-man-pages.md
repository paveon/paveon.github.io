---
id: man-pages
title: Infer Manuals
---

Here are the man pages for all the infer commands:

- [infer](/man/infer.1.html)
- [infer-analyze](/man/infer-analyze.1.html)
- [infer-capture](/man/infer-capture.1.html)
- [infer-compile](/man/infer-compile.1.html)
- [infer-explore](/man/infer-explore.1.html)
- [infer-report](/man/infer-report.1.html)
- [infer-reportdiff](/man/infer-reportdiff.1.html)
- [infer-run](/man/infer-run.1.html)
